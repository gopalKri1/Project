export const constants = {
  ADD_ROW: "addrows",
  DELETE_ROW: "deleterow",
  UPDATE_ROW: "updaterow",
};

export default constants;